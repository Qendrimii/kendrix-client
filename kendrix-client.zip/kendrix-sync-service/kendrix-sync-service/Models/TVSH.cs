using System;

namespace kendrix_sync_service.Models
{
    public class TVSH : BaseEntity
    {
        public decimal Perqindja { get; set; }
        public string Grupi { get; set; }
    }
}

